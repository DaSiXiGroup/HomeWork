#include "App.h"

int main(){
    // Let App own the lifecycle; main should stay boring.
    pathlab::App app;
    app.Run();
    return 0;
}
